export default {
  base: '/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets'
  }
}