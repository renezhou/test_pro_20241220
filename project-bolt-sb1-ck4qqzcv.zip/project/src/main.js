import { AnalogClock } from './components/Clock/AnalogClock.js';
import { DigitalClock } from './components/Clock/DigitalClock.js';
import { initializeClocks } from './init/clockInit.js';

// Initialize both clocks
initializeClocks();