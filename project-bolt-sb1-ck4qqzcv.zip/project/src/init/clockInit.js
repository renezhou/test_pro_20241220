import { AnalogClock } from '../components/Clock/AnalogClock.js';
import { DigitalClock } from '../components/Clock/DigitalClock.js';

export function initializeClocks() {
  const analogClock = new AnalogClock(document.querySelector('.clock'));
  const digitalClock = new DigitalClock(document.querySelector('.digital-clock'));

  analogClock.start();
  digitalClock.start();
}