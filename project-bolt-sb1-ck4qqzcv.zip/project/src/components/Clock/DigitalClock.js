import { formatTime } from '../../utils/timeUtils';

export class DigitalClock {
  constructor(container) {
    this.container = container;
  }

  update() {
    const now = new Date();
    const { hours, minutes, seconds } = formatTime(now);
    this.container.textContent = 
      `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  start() {
    setInterval(() => this.update(), 1000);
    this.update();
  }
}