import { formatTime } from '../../utils/timeUtils';

export class AnalogClock {
  constructor(container) {
    this.container = container;
    this.hourHand = container.querySelector('.hour-hand');
    this.minuteHand = container.querySelector('.minute-hand');
    this.secondHand = container.querySelector('.second-hand');
  }

  update() {
    const now = new Date();
    const { hours, minutes, seconds } = formatTime(now);
    
    const secondsDegrees = (seconds / 60) * 360 + 90;
    const minutesDegrees = (minutes / 60) * 360 + (seconds / 60) * 6 + 90;
    const hoursDegrees = (hours / 12) * 360 + (minutes / 60) * 30 + 90;

    this.secondHand.style.transform = `rotate(${secondsDegrees}deg)`;
    this.minuteHand.style.transform = `rotate(${minutesDegrees}deg)`;
    this.hourHand.style.transform = `rotate(${hoursDegrees}deg)`;
  }

  start() {
    setInterval(() => this.update(), 1000);
    this.update();
  }
}